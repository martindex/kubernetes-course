package org.martindex.springcloud.ms.courses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCoursesApplicationTests {

	@Test
	void contextLoads() {
	}

}
